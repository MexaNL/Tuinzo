import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Heart } from "lucide-react";
import { ProductCard, type ProductCardData } from "@/components/ProductCard";
import { SiteHeader, SiteFooter } from "@/components/SiteChrome";
import { SEO } from "@/components/SEO";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { useFavorites } from "@/hooks/useFavorites";

const FavoritesPage = () => {
  const { ids } = useFavorites();
  const [products, setProducts] = useState<ProductCardData[]>([]);

  useEffect(() => {
    if (ids.length === 0) { setProducts([]); return; }
    supabase.from("products")
      .select("id,slug,title,short_description,usp,image_url,affiliate_url,price_label,rating,is_best_choice,retailer")
      .in("slug", ids)
      .then(({ data }) => data && setProducts(data as ProductCardData[]));
  }, [ids]);

  return (
    <div className="min-h-screen bg-background">
      <SEO title="Favorieten — Gardino" description="Jouw bewaarde tuinproducten." />
      <SiteHeader />
      <section className="container py-10">
        <div className="mb-6 flex items-center gap-3">
          <Heart className="h-6 w-6 text-accent" />
          <h1 className="font-display text-2xl font-extrabold text-foreground md:text-3xl">Mijn favorieten</h1>
        </div>
        {products.length === 0 ? (
          <div className="rounded-lg border border-dashed border-border bg-card p-10 text-center">
            <p className="text-muted-foreground">Je hebt nog geen favorieten opgeslagen.</p>
            <Button asChild className="mt-4"><Link to="/">Bekijk producten</Link></Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-3 lg:grid-cols-4">
            {products.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        )}
      </section>
      <SiteFooter />
    </div>
  );
};

export default FavoritesPage;
