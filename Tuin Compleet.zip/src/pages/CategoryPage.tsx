import { useEffect, useMemo, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { SiteHeader, SiteFooter } from "@/components/SiteChrome";
import { ProductCard, type ProductCardData } from "@/components/ProductCard";
import { SEO, breadcrumbJsonLd } from "@/components/SEO";
import { supabase } from "@/integrations/supabase/client";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { SlidersHorizontal, X } from "lucide-react";
import { TileM2Input } from "@/components/TileM2Input";
import { useTileM2, calcTilePrice } from "@/hooks/useTileM2";

const PRODUCT_SELECT =
  "id,slug,title,short_description,usp,image_url,affiliate_url,price_label,price_numeric,rating,is_best_choice,retailer,sort_order,tile_size_m2,price_per_unit";

type DBProduct = ProductCardData & { price_numeric: number | null; sort_order: number };

const TILE_SLUG = "tuintegels";

type SortKey = "popular" | "price_asc" | "price_desc" | "rating_desc";

const CategoryPage = () => {
  const { slug } = useParams<{ slug: string }>();
  const [category, setCategory] = useState<{ id: string; name: string; description: string | null } | null>(null);
  const [products, setProducts] = useState<DBProduct[]>([]);
  const [notFound, setNotFound] = useState(false);

  // Filters
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 0]);
  const [priceBounds, setPriceBounds] = useState<[number, number]>([0, 0]);
  const [selectedRetailers, setSelectedRetailers] = useState<string[]>([]);
  const [minRating, setMinRating] = useState<number>(0);
  const [sort, setSort] = useState<SortKey>("popular");

  useEffect(() => {
    if (!slug) return;
    setNotFound(false);
    (async () => {
      const { data: cat } = await supabase.from("categories").select("id,name,description").eq("slug", slug).maybeSingle();
      if (!cat) { setNotFound(true); return; }
      setCategory(cat as any);
      const { data: prods } = await supabase
        .from("products")
        .select(PRODUCT_SELECT)
        .eq("category_id", (cat as any).id)
        .order("is_best_choice", { ascending: false })
        .order("sort_order");
      const list = (prods ?? []) as DBProduct[];
      setProducts(list);

      // Init price bounds
      const prices = list.map((p) => p.price_numeric).filter((n): n is number => typeof n === "number" && n > 0);
      if (prices.length) {
        const min = Math.floor(Math.min(...prices));
        const max = Math.ceil(Math.max(...prices));
        setPriceBounds([min, max]);
        setPriceRange([min, max]);
      } else {
        setPriceBounds([0, 0]);
        setPriceRange([0, 0]);
      }
      setSelectedRetailers([]);
      setMinRating(0);
      setSort("popular");
    })();
  }, [slug]);

  const retailers = useMemo(() => {
    const map = new Map<string, number>();
    products.forEach((p) => {
      if (p.retailer) map.set(p.retailer, (map.get(p.retailer) ?? 0) + 1);
    });
    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]);
  }, [products]);

  const isTileCategory = slug === TILE_SLUG;
  const { m2, joint, waste } = useTileM2();

  const effectivePrice = (p: DBProduct) => {
    if (isTileCategory) {
      const t = calcTilePrice(p.price_per_unit, p.tile_size_m2, m2, { jointMm: joint, wastePct: waste });
      if (t) return t.total;
    }
    return p.price_numeric ?? null;
  };

  const filtered = useMemo(() => {
    let list = products.filter((p) => {
      if (selectedRetailers.length && (!p.retailer || !selectedRetailers.includes(p.retailer))) return false;
      if (minRating > 0 && (p.rating ?? 0) < minRating) return false;
      if (priceBounds[1] > 0 && typeof p.price_numeric === "number") {
        if (p.price_numeric < priceRange[0] || p.price_numeric > priceRange[1]) return false;
      }
      return true;
    });
    switch (sort) {
      case "price_asc":
        list = [...list].sort((a, b) => (effectivePrice(a) ?? Infinity) - (effectivePrice(b) ?? Infinity));
        break;
      case "price_desc":
        list = [...list].sort((a, b) => (effectivePrice(b) ?? -1) - (effectivePrice(a) ?? -1));
        break;
      case "rating_desc":
        list = [...list].sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0));
        break;
      default:
        list = [...list].sort((a, b) => Number(b.is_best_choice) - Number(a.is_best_choice) || a.sort_order - b.sort_order);
    }
    return list;
  }, [products, selectedRetailers, minRating, priceRange, priceBounds, sort, isTileCategory, m2, joint, waste]);

  const toggleRetailer = (r: string) =>
    setSelectedRetailers((prev) => (prev.includes(r) ? prev.filter((x) => x !== r) : [...prev, r]));

  const activeFilterCount =
    selectedRetailers.length + (minRating > 0 ? 1 : 0) + (priceBounds[1] > 0 && (priceRange[0] !== priceBounds[0] || priceRange[1] !== priceBounds[1]) ? 1 : 0);

  const resetFilters = () => {
    setSelectedRetailers([]);
    setMinRating(0);
    setPriceRange(priceBounds);
  };

  const FiltersPanel = () => (
    <div className="space-y-6">
      {priceBounds[1] > 0 && (
        <div>
          <h3 className="mb-3 font-display text-sm font-bold uppercase tracking-wide">Prijs</h3>
          <Slider
            min={priceBounds[0]}
            max={priceBounds[1]}
            step={1}
            value={priceRange}
            onValueChange={(v) => setPriceRange([v[0], v[1]] as [number, number])}
          />
          <div className="mt-2 flex justify-between text-xs text-muted-foreground">
            <span>€ {priceRange[0]}</span>
            <span>€ {priceRange[1]}</span>
          </div>
        </div>
      )}

      {retailers.length > 0 && (
        <div>
          <h3 className="mb-3 font-display text-sm font-bold uppercase tracking-wide">Winkel</h3>
          <div className="space-y-2">
            {retailers.map(([r, count]) => (
              <label key={r} className="flex cursor-pointer items-center gap-2 text-sm">
                <Checkbox checked={selectedRetailers.includes(r)} onCheckedChange={() => toggleRetailer(r)} />
                <span className="flex-1">{r}</span>
                <span className="text-xs text-muted-foreground">({count})</span>
              </label>
            ))}
          </div>
        </div>
      )}

      <div>
        <h3 className="mb-3 font-display text-sm font-bold uppercase tracking-wide">Beoordeling</h3>
        <div className="space-y-2">
          {[0, 3, 4, 4.5].map((r) => (
            <label key={r} className="flex cursor-pointer items-center gap-2 text-sm">
              <input
                type="radio"
                name="rating"
                checked={minRating === r}
                onChange={() => setMinRating(r)}
                className="accent-primary"
              />
              <span>{r === 0 ? "Alle" : `${r}+ sterren`}</span>
            </label>
          ))}
        </div>
      </div>

      {activeFilterCount > 0 && (
        <Button variant="outline" size="sm" onClick={resetFilters} className="w-full">
          <X className="mr-1 h-3 w-3" /> Filters wissen
        </Button>
      )}
    </div>
  );

  if (notFound) {
    return (
      <div className="min-h-screen">
        <SiteHeader />
        <div className="container py-20 text-center">
          <h1 className="font-display text-3xl">Categorie niet gevonden</h1>
          <Link to="/" className="mt-4 inline-block text-primary underline">Terug naar home</Link>
        </div>
      </div>
    );
  }

  const origin = typeof window !== "undefined" ? window.location.origin : "";

  return (
    <div className="min-h-screen bg-background">
      {category && (
        <SEO
          title={`${category.name} — Gardino`}
          description={category.description ?? `${category.name} vergelijken op Gardino.`}
          jsonLd={[
            breadcrumbJsonLd([
              { name: "Home", url: `${origin}/` },
              { name: category.name, url: `${origin}/categorie/${slug}` },
            ]),
          ]}
        />
      )}
      <SiteHeader />
      <section className="border-b border-border bg-gradient-warm">
        <div className="container py-5 md:py-7">
          <p className="text-xs text-muted-foreground">
            <Link to="/" className="hover:text-primary">Home</Link> / {category?.name}
          </p>
          <div className="mt-1 flex flex-wrap items-baseline gap-x-3 gap-y-1">
            <h1 className="font-display text-2xl font-extrabold text-foreground md:text-4xl">{category?.name}</h1>
            <span className="text-sm text-muted-foreground">{filtered.length} van {products.length} producten</span>
          </div>
          {category?.description && (
            <p className="mt-2 max-w-2xl text-sm text-muted-foreground md:text-base">{category.description}</p>
          )}
        </div>
      </section>

      <section className="container py-6">
        {isTileCategory && <TileM2Input variant="sticky" className="md:!static md:mb-4" />}
        {/* Toolbar */}
        <div className="mb-4 flex items-center justify-between gap-2">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="sm" className="md:hidden">
                <SlidersHorizontal className="mr-1 h-4 w-4" />
                Filters {activeFilterCount > 0 && <span className="ml-1 rounded-full bg-primary px-1.5 text-[10px] text-primary-foreground">{activeFilterCount}</span>}
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[85vw] max-w-sm overflow-y-auto">
              <SheetHeader>
                <SheetTitle className="font-display">Filters</SheetTitle>
              </SheetHeader>
              <div className="mt-6"><FiltersPanel /></div>
            </SheetContent>
          </Sheet>
          <div className="hidden md:block" />
          <Select value={sort} onValueChange={(v) => setSort(v as SortKey)}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Sorteer" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="popular">Populair</SelectItem>
              <SelectItem value="price_asc">Prijs: laag → hoog</SelectItem>
              <SelectItem value="price_desc">Prijs: hoog → laag</SelectItem>
              <SelectItem value="rating_desc">Hoogste beoordeling</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid gap-6 md:grid-cols-[220px_1fr]">
          {/* Sidebar (desktop) */}
          <aside className="hidden md:block">
            <FiltersPanel />
          </aside>

          {/* Grid */}
          <div>
            {filtered.length === 0 ? (
              <p className="text-sm text-muted-foreground">Geen producten gevonden met deze filters.</p>
            ) : (
              <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-3 xl:grid-cols-4">
                {filtered.map((p) => <ProductCard key={p.id} product={p} />)}
              </div>
            )}
          </div>
        </div>
      </section>
      <SiteFooter />
    </div>
  );
};

export default CategoryPage;
