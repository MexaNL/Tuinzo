import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { ArrowUpRight, Star, Check, X, Award, ChevronLeft, Truck, ShieldCheck, RotateCcw, Lock } from "lucide-react";
import { SiteHeader, SiteFooter } from "@/components/SiteChrome";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ProductCard, type ProductCardData } from "@/components/ProductCard";
import { SEO, breadcrumbJsonLd } from "@/components/SEO";
import { TileM2Input } from "@/components/TileM2Input";
import { useTileM2, calcTilePrice, formatEuro } from "@/hooks/useTileM2";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

interface Product {
  id: string; slug: string; title: string; short_description: string;
  usp: string | null; image_url: string; affiliate_url: string;
  price_label: string | null; price_numeric: number | null; rating: number | null; is_best_choice: boolean;
  retailer: string | null;
  pros: string[] | null; cons: string[] | null;
  review_md: string | null;
  category_id: string | null;
  tile_size_m2: number | null;
  price_per_unit: number | null;
}

const PRODUCT_SELECT = "id,slug,title,short_description,usp,image_url,affiliate_url,price_label,rating,is_best_choice,retailer,tile_size_m2,price_per_unit";

const ProductPage = () => {
  const { slug } = useParams<{ slug: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [related, setRelated] = useState<ProductCardData[]>([]);
  const [category, setCategory] = useState<{ name: string; slug: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const { m2, joint, waste } = useTileM2();

  useEffect(() => {
    if (!slug) return;
    (async () => {
      setLoading(true);
      const { data } = await supabase.from("products").select("*").eq("slug", slug).maybeSingle();
      setProduct(data as Product | null);
      if (data?.category_id) {
        const [{ data: rel }, { data: cat }] = await Promise.all([
          supabase.from("products").select(PRODUCT_SELECT).eq("category_id", data.category_id).neq("id", data.id).limit(4),
          supabase.from("categories").select("name,slug").eq("id", data.category_id).maybeSingle(),
        ]);
        setRelated((rel ?? []) as ProductCardData[]);
        if (cat) setCategory(cat as any);
      }
      setLoading(false);
    })();
  }, [slug]);

  if (loading) return <div className="min-h-screen"><SiteHeader /><div className="container py-24 text-center text-muted-foreground">Laden…</div></div>;
  if (!product) return (
    <div className="min-h-screen"><SiteHeader />
      <div className="container py-24 text-center">
        <h1 className="font-display text-3xl">Product niet gevonden</h1>
        <Link to="/" className="mt-4 inline-block text-primary underline">Terug naar home</Link>
      </div>
    </div>
  );

  const origin = typeof window !== "undefined" ? window.location.origin : "";
  const productUrl = `${origin}/product/${product.slug}`;

  return (
    <div className="min-h-screen bg-background">
      <SEO
        title={`${product.title} — Gardino`}
        description={product.short_description}
        canonical={productUrl}
        image={/^https?:/.test(product.image_url) ? product.image_url : `${origin}${product.image_url}`}
        type="product"
        jsonLd={[
          breadcrumbJsonLd([
            { name: "Home", url: `${origin}/` },
            ...(category ? [{ name: category.name, url: `${origin}/categorie/${category.slug}` }] : []),
            { name: product.title, url: productUrl },
          ]),
        ]}
      />
      <SiteHeader />

      <div className="container max-w-6xl pt-3">
        <Link
          to={category ? `/categorie/${category.slug}` : "/"}
          className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-primary"
        >
          <ChevronLeft className="h-3.5 w-3.5" />
          {category ? `Terug naar ${category.name}` : "Terug naar overzicht"}
        </Link>
      </div>

      {/* Header */}
      <section className="container max-w-6xl pt-3 md:pt-6">
        <div className="max-w-3xl">
          <div className="flex flex-wrap items-center gap-2 text-xs">
            {product.is_best_choice && (
              <Badge className="bg-primary text-primary-foreground hover:bg-primary">
                <Award className="mr-1 h-3 w-3" /> Redactiekeuze
              </Badge>
            )}
            {category && (
              <Link to={`/categorie/${category.slug}`} className="text-muted-foreground hover:text-primary">
                {category.name}
              </Link>
            )}
          </div>
          <h1 className="mt-2 font-display text-3xl leading-[1.1] text-foreground md:text-5xl">{product.title}</h1>
          <p className="mt-3 text-sm text-muted-foreground md:text-base">{product.short_description}</p>
          {product.rating && (
            <div className="mt-3 inline-flex items-center gap-1 text-sm text-foreground">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={cn("h-4 w-4", i < Math.round(product.rating!) ? "fill-accent text-accent" : "text-muted-foreground/40")}
                />
              ))}
              <strong className="ml-1">{product.rating.toFixed(1)}</strong>
              <span className="text-muted-foreground">/ 5</span>
            </div>
          )}
        </div>
      </section>

      {/* Hero grid */}
      <section className="container max-w-6xl py-6 md:py-8">
        <div className="grid gap-6 md:grid-cols-[1fr_380px] md:gap-10 lg:grid-cols-[1fr_420px]">
          <div className="min-w-0">
            <a
              href={product.affiliate_url}
              target="_blank"
              rel="sponsored noopener noreferrer"
              className="relative block aspect-[4/5] overflow-hidden rounded-2xl bg-card shadow-card md:aspect-[5/6]"
            >
              <img
                src={product.image_url}
                alt={product.title}
                className="h-full w-full object-cover transition-transform duration-700 hover:scale-[1.03]"
                width={1200}
                height={1500}
                loading="eager"
              />
            </a>
            <div className="mt-4 hidden grid-cols-3 gap-3 md:grid">
              <div className="flex items-start gap-2 rounded-lg border border-border bg-card p-3">
                <Truck className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                <div className="text-xs">
                  <p className="font-semibold text-foreground">Snelle levering</p>
                  <p className="text-muted-foreground">Direct vanuit voorraad partner</p>
                </div>
              </div>
              <div className="flex items-start gap-2 rounded-lg border border-border bg-card p-3">
                <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                <div className="text-xs">
                  <p className="font-semibold text-foreground">Garantie</p>
                  <p className="text-muted-foreground">Officiële fabrieksgarantie</p>
                </div>
              </div>
              <div className="flex items-start gap-2 rounded-lg border border-border bg-card p-3">
                <RotateCcw className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                <div className="text-xs">
                  <p className="font-semibold text-foreground">Niet goed, geld terug</p>
                  <p className="text-muted-foreground">30 dagen bedenktijd</p>
                </div>
              </div>
            </div>
          </div>

          <aside>
            <div className="md:sticky md:top-4">
              <div className="overflow-hidden rounded-2xl border border-border bg-card shadow-card">
                {(() => {
                  const tile = calcTilePrice(product.price_per_unit, product.tile_size_m2, m2, { jointMm: joint, wastePct: waste });
                  if (tile) {
                    return (
                      <div className="border-b border-border p-5">
                        <TileM2Input variant="inline" className="!border-0 !bg-transparent !p-0 !shadow-none" />
                        <div className="mt-4">
                          <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Totaal voor {m2} m² (incl. {waste}% snijverlies)</span>
                          <p className="font-display text-4xl leading-none text-primary">{formatEuro(tile.total)}</p>
                          <p className="mt-1 text-[11px] text-muted-foreground">
                            {tile.tilesNeeded} tegels × {formatEuro(product.price_per_unit!)} · {product.tile_size_m2} m²/tegel · voeg {joint} mm
                          </p>
                        </div>
                      </div>
                    );
                  }
                  return product.price_label ? (
                    <div className="border-b border-border p-5">
                      <span className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Prijs</span>
                      <p className="font-display text-4xl leading-none text-primary">{product.price_label}</p>
                      <p className="mt-1 text-[11px] text-muted-foreground">Prijs incl. btw, excl. verzending</p>
                    </div>
                  ) : null;
                })()}
                <div className="p-5">
                  <Button asChild size="lg" className="w-full bg-accent text-accent-foreground hover:bg-accent/90 shadow-cta">
                    <a
                      href={product.affiliate_url}
                      target="_blank"
                      rel="sponsored noopener noreferrer"
                    >
                      Bekijk bij {product.retailer ?? "shop"}
                      <ArrowUpRight className="h-4 w-4" />
                    </a>
                  </Button>
                  <div className="mt-3 flex items-center justify-center gap-1.5 text-[11px] text-muted-foreground">
                    <Lock className="h-3 w-3" /> Veilige doorverwijzing naar partner
                  </div>
                </div>
                <ul className="space-y-2 border-t border-border bg-muted/30 px-5 py-4 text-xs text-foreground">
                  <li className="flex items-center gap-2"><Check className="h-3.5 w-3.5 shrink-0 text-brand-leaf" /> Snelle thuislevering</li>
                  <li className="flex items-center gap-2"><Check className="h-3.5 w-3.5 shrink-0 text-brand-leaf" /> Officiële garantie</li>
                  <li className="flex items-center gap-2"><Check className="h-3.5 w-3.5 shrink-0 text-brand-leaf" /> Veilig betalen via partner</li>
                </ul>
              </div>
              <p className="mt-2 text-center text-[10px] text-muted-foreground">
                * Affiliate-link. Als je iets koopt, krijgen wij mogelijk een kleine vergoeding.
              </p>
            </div>
          </aside>
        </div>
      </section>

      {/* Pros & cons */}
      {(product.pros?.length || product.cons?.length) ? (
        <section className="container max-w-6xl pb-10">
          <div className="grid gap-6 md:grid-cols-2">
            {product.pros && product.pros.length > 0 && (
              <div className="rounded-lg border border-border bg-card p-5">
                <h3 className="font-display text-lg font-bold text-foreground">Pluspunten</h3>
                <ul className="mt-3 space-y-2 text-sm">
                  {product.pros.map((p) => (
                    <li key={p} className="flex items-start gap-2"><Check className="mt-0.5 h-4 w-4 shrink-0 text-brand-leaf" /> {p}</li>
                  ))}
                </ul>
              </div>
            )}
            {product.cons && product.cons.length > 0 && (
              <div className="rounded-lg border border-border bg-card p-5">
                <h3 className="font-display text-lg font-bold text-foreground">Aandachtspunten</h3>
                <ul className="mt-3 space-y-2 text-sm">
                  {product.cons.map((c) => (
                    <li key={c} className="flex items-start gap-2"><X className="mt-0.5 h-4 w-4 shrink-0 text-destructive" /> {c}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </section>
      ) : null}

      {/* Related */}
      {related.length > 0 && (
        <section className="container max-w-6xl pb-16">
          <h2 className="font-display text-2xl font-extrabold text-foreground mb-4">Ook interessant</h2>
          <div className="grid grid-cols-2 gap-3 sm:gap-4 md:grid-cols-4">
            {related.map((p) => <ProductCard key={p.id} product={p} />)}
          </div>
        </section>
      )}

      <SiteFooter />
    </div>
  );
};

export default ProductPage;
